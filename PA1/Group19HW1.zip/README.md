# INF124Spring2022

Team Members: Andrew J. Owyang, Huan Quang Nguyen, Katie Chow

Site Navigation:
- There are 4 pages in total: Home, Products, Item Description, Team.
- Each page will have a navigation bar at the top that takes the user to 3 pages: Home, Products, Team.

Home Page --> The user will land on the home page when starting the index.html file, this is merely a landing page for users to enter the site. Using the top nav bar allows the user to exit this page.

Products Page --> This page hosts the items offerd on our site. The page is vertically scrollable and hovering over an item will zoom in on the product. Clicking on an item will take the user to that items description page which will have more details on the product selected.

Item Description Page --> This page includes more pictures of the product as well as a description of what the product is. Under that is the form that allows users to checkout their selected items. This form includes all of the requirements from number 6 & 7 of the project rubric. Users can navigate off this page by using the top nav bar. 

Team Page --> This page hosts a description of the site and a short biogrpahy section for our 3 team members. It also includes the top nav bar.
